# Fiche Google Play – IA Creator

**Nom (30 car. max)** : IA Creator
**Description courte (80 car. max)** : Apprends l’IA, crée du contenu pro et monétise sur les réseaux sociaux.
**Catégorie** : Éducation · **Langue** : Français · **Gratuit avec achats/abonnements**

## Description complète
IA Creator t’apprend à utiliser l’intelligence artificielle pour créer du contenu professionnel, lancer ton activité en ligne et générer des revenus grâce aux réseaux sociaux.

Apprends • Crée • Monétise

FORMATIONS : Facebook, TikTok, YouTube, vidéo IA, logos, affiches, vidéos publicitaires, business IA, marketing digital, monétisation (Facebook, TikTok, YouTube), ChatGPT, avatars IA, musique IA, sites web, applications, images IA, CV, cartes de visite, boutiques en ligne.

FONCTIONNALITÉS : quiz, suivi de progression, tableau de bord, bibliothèque de prompts IA, attestation et certificat de réussite.

ABONNEMENTS : Starter (formations de base), Pro (toutes les formations + attestation), Premium (accès illimité, tous les prompts professionnels, attestation, certificat et futures mises à jour).

Contact : WhatsApp 0504628608

## Questionnaire « Sécurité des données » (suggestion)
- Données collectées : nom, email/téléphone (saisis par l’utilisateur).
- Stockage : uniquement sur l’appareil, aucun envoi vers un serveur.
- Partage avec des tiers : non. Suppression : via Déconnexion / désinstallation.
- À mettre à jour si vous ajoutez un serveur ou un système de comptes.

## Éléments à fournir à Google
- Icône 512×512 : icon-512.png · Image de présentation 1024×500 : feature-graphic-1024x500.png
- 2 à 8 captures d’écran du téléphone (faites-les depuis l’app installée)
- URL de la politique de confidentialité : l’adresse de privacy.html une fois hébergée
- Classification du contenu : questionnaire IARC (public tout âge, sans violence)
