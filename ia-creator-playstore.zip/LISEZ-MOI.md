# IA Creator – Passer sur le Play Store

## 1. Héberger le site (gratuit, 5 minutes)
Allez sur netlify.com → « Add new site » → « Deploy manually » → glissez le CONTENU de ce dossier (index.html, manifest.webmanifest, sw.js, icônes, privacy.html). Vous obtenez une adresse https://xxx.netlify.app.
Ouvrez-la sur votre téléphone : Chrome propose « Installer l’application » (la PWA fonctionne déjà).

## 2. Créer le fichier Android
Allez sur pwabuilder.com, collez votre adresse https://…, cliquez Start → Package for stores → Android → Google Play. Téléchargez le fichier .aab et conservez la clé de signature (signing key) en lieu sûr.

## 3. Publier
- Créez un compte sur play.google.com/console (25 $, une seule fois).
- Créez l’application, envoyez le .aab, remplissez la fiche avec store-listing.md.
- Indiquez l’adresse de privacy.html comme politique de confidentialité.
- Les nouveaux comptes personnels doivent souvent faire un test fermé (environ 12 testeurs pendant 14 jours) avant la production : vérifiez les règles actuelles dans la console.

## Points d’attention
- Paiement : Google exige Google Play Billing pour vendre du contenu numérique DANS l’application. Vérifiez la règle avant de publier, car vos abonnements Mobile Money passent par WhatsApp.
- Codes d’activation et certificats : sans serveur, ils ne sont pas sécurisés. Prévoir un vrai système de comptes plus tard.
- Remplacez [VOTRE EMAIL] dans privacy.html.
